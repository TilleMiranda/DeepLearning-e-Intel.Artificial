# Deep Learning Book
Repositório do Deep Learning Book - Em português, online e gratuito.

Aqui você encontra os scripts usados no livro online. Para mais informações acesse: www.deeplearningbook.com.br
